# Projeto Cypress

Este projeto utiliza o framework de teste de ponta a ponta Cypress.

## Pré-requisitos

- Node.js v12.0.0 ou superior
- npm v6.9.0 ou superior

## Instalação

1. Clone o repositório ou faça o download dos arquivos do projeto.
2. Navegue até a pasta do projeto usando o terminal.
3. Execute o comando `npm init` para iniciar o projeto npm (se necessário).
4. Execute o comando `npm install cypress --save-dev` para instalar o Cypress como uma dependência de desenvolvimento.
5. Execute o comando `npm install` para instalar todas as outras dependências do projeto.

## Executando testes

- Para executar os testes no Chrome, execute o comando ` npx cypress run --spec "cypress/e2e/*"`

