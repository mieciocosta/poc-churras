describe('Cadastro de usuário no Site Churras', () => {
    beforeEach(() => {
        cy.viewport(375, 812);
      cy.visit('https://trinca-bbq.vercel.app/cadastro/');
    });
  
    it('Cadastro de usuário', () => {

        const randomNumber = Math.floor(Math.random() * 100000);

        cy.get('[name="email"]')
          .clear()
          // Concatenar o número aleatório ao endereço de email
          .type(`novousuario${randomNumber}@email.com`);

      cy.get('[name="password"]')
        .clear()
        .type('123456');
        cy.get('.sc-hLseeU').click({force: true});
      // Verifique se o cadastro do usuário foi bem-sucedido
    });
  });
  