describe('Edição de informações do evento no Site Churras', () => {

  
    it('Login com credenciais corretas', () => {
      cy.viewport(375, 812);
      cy.visit('https://trinca-bbq.vercel.app/login/');
      cy.get('[name="email"]')
        .clear()
        .type('a@a.com');
      cy.get('[name="password"]')
        .clear()
        .type('123456');
        cy.get('[data-testid="submit_button"]').click({force: true});
        cy.on('window:alert', (str) => {
          // Verificar se o texto do alerta é "sucesso!"
          expect(str).to.equal('sucesso!');
        });
        cy.wait(3000);
        
        const paths = [
          "[href='/churras/formulario/011ed8e5-1a3f-40c5-8aa3-665032577a69/'] span:nth-of-type(1)",
          "[href='/churras/formulario/025cd37a-2e8d-4dd5-a104-5764324722b8/'] span:nth-of-type(1)",
          "[href='/churras/formulario/044dd6bf-d079-4b01-8711-11d9742be740/'] span:nth-of-type(2)",
          "[href='/churras/formulario/05b7c911-3487-4b53-9558-c4783e8125fe/'] span:nth-of-type(2)",
          "[href='/churras/formulario/06899831-5dbb-4e72-b37f-a6b9d858c792/'] span:nth-of-type(2)",
          "[href='/churras/formulario/10b08ded-56a9-43dd-bd4c-936533565e65/'] span:nth-of-type(2)"
        ];
    
        const randomIndex = Math.floor(Math.random() * paths.length);
        const randomPath = paths[randomIndex];
    
        cy.get(randomPath).click();

        cy.get('[name="title"]')
        .clear()
        .type('teste miecio');
      cy.get('[name="price"]')
        .clear()
        .type('100');
      cy.get('[name="date"]')
        .clear()
        .type('1988-01-01');
      cy.get('[name="observations"]')
        .clear()
        .type('teste automatizado com cypress - miecio');
      cy.get('[data-testid="submit_button"]').click();
      cy.wait(3000);
      cy.on('window:alert', (str2) => {
        // Verificar se o texto do alerta é "sucesso!"
        expect(str2).to.equal('sucesso!');
      })
      });
    
  });

  