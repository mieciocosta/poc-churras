describe('Login no Site Churras', () => {
    beforeEach(() => {
      cy.viewport(375, 812);
      cy.visit('https://trinca-bbq.vercel.app/login/');
      // Aqui você deve implementar a lógica para garantir que o usuário é um usuário cadastrado
    });
  
    it('Login com credenciais corretas', () => {
      cy.get('[name="email"]')
        .clear()
        .type('a@a.com');
      cy.get('[name="password"]')
        .clear()
        .type('123456');
        cy.get('[data-testid="submit_button"]').click({force: true});
      });
  });
  